﻿namespace RealWorldApp.Models
{
    public class CommentRequest
    {
        public Comment Comment { get; set; } = new();
    }
}
